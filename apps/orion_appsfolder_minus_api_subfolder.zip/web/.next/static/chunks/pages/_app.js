__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__e2c08166._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_a51498a5._.js",
  "static/chunks/[root-of-the-server]__20ba2906._.js",
  "static/chunks/apps_web_pages__app_5771e187._.js",
  "static/chunks/apps_web_pages__app_84ad9cf5._.js"
])
