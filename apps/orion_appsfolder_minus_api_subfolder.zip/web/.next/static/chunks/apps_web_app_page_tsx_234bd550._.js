(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_96ff9d06._.js",
  "static/chunks/apps_web_app_2402a9e3._.js",
  "static/chunks/apps_web_app_page_module_0fa98f0d.css"
],
    source: "dynamic"
});
