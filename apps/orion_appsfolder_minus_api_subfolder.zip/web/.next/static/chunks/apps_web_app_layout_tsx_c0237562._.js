(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_app_5dd51fc7._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_471587df._.js",
  "static/chunks/node_modules_f2f454f9._.js"
],
    source: "dynamic"
});
